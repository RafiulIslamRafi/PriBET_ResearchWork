#include<bits/stdc++.h>
#include "stopwords.h"
#include "hashing.h"
#include "DecimaltoHexaDecimal.h"

#define Coefficient 32609

using namespace std;

unordered_map<string, int>mp;
vector<pair<int,int>>v;
void DocumentToVector(string &filename)
{
    ///freopen(filename.c_str(),"r",stdin);
    ifstream cin(filename.c_str());
    init();
    string str;
    while(cin>>str){
		//cout<<str<<endl;
        if(!isStopWord(str)){
            if(mp.find(str)!=mp.end()){
                mp[str]++;
            }
            else mp[str] = 1;
        }
    }
    for(auto it = mp.begin(); it != mp.end(); it++){
		v.push_back({wordToInt(it->first), it->second});
    }
    mp.clear();
}
string poly(){
	//cout<<v.size()<<endl;
	sort(v.rbegin(), v.rend());
	string poly = "";
	for(int i=0; i<v.size(); i++){
        if(!poly.size()) poly = to_string(v[i].second) + "x^" + to_string(v[i].first);
        else poly += " + " + to_string(v[i].second) + "x^" + to_string(v[i].first);
    }
    v.clear();
    return poly;
}

string documentToPolynomial(string filename){
	DocumentToVector(filename);
	return poly();
}
string documentToReversePolynomial(string filename){
	v.clear();
	mp.clear();
	DocumentToVector(filename);
	for(int i=0;i<v.size();i++) v[i].first = Coefficient - v[i].first;
	return poly();
}

pair<string, string> documentToPolynomialwithReverse(string filename){
	return {documentToPolynomial(filename), documentToReversePolynomial(filename)};
}

pair<int, int> f(string &term){
	for(int i=0; i<term.size(); i++){
		if(term[i]=='^') {
			///cout<<i<<endl;
			///cout<<term.substr(i+1,term.size()-i)<<endl;
			if(term.substr(i+1,term.size()-i) == to_string(Coefficient)){
				///cout<<term.substr(0,i-1)<<endl;
				return {true, stoi(term.substr(0,i-1))};
			}
			else return {false,0};
		}
	}
	return {false,0};
}

int CoefficientforDocument(string str){
	string term;
	stringstream ss(str);
	while(ss>>term){
		//cout<<term<<endl;
		pair<int, int> pi = f(term);
		if(pi.first) return pi.second;
	}
	return 0;
}
