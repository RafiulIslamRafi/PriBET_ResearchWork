#include<bits/stdc++.h>
#include "documentToPolynolomial.h"
using namespace std;
#define FO               freopen("out.txt","w",stdout)

int main(){
	FO;
	//cout<<documentToPolynomial("Fiji2014.txt")<<endl<<documentToReversePolynomial("Fiji2014.txt")<<endl<<endl;
	cout<<documentToPolynomial("Fiji2016.txt")<<endl<<documentToReversePolynomial("Fiji2016.txt")<<endl<<endl;
	return 0;
}
